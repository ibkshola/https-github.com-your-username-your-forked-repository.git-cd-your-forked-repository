
class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):
        print(f"Restaurant Name: {self.restaurant_name}")
        print(f"Cuisine Type: {self.cuisine_type}")

    def open_restaurant(self):
        print(f"{self.restaurant_name} is now open!")

    def set_number_served(self, number):
        self.number_served = number

    def increment_number_served(self, increment):
        self.number_served += increment

    def display_number_served(self):
        print(f"Number of customers served: {self.number_served}")


class IceCreamStand(Restaurant):
    def __init__(self, restaurant_name, cuisine_type, flavors):
        super().__init__(restaurant_name, cuisine_type)
        self.flavors = flavors

    def display_flavors(self):
        print("Ice Cream Flavors:")
        for flavor in self.flavors:
            print(f"- {flavor}")


# Creating an instance of Restaurant
restaurant = Restaurant("Pizzeria", "Italian")
print("Restaurant Name:", restaurant.restaurant_name)
print("Cuisine Type:", restaurant.cuisine_type)
restaurant.describe_restaurant()
restaurant.open_restaurant()

# Creating three instances of Restaurant and calling describe_restaurant() for each
restaurant1 = Restaurant("Burger Shack", "Fast Food")
restaurant2 = Restaurant("Sushi Palace", "Japanese")
restaurant3 = Restaurant("Taco Town", "Mexican")

restaurant1.describe_restaurant()
restaurant2.describe_restaurant()
restaurant3.describe_restaurant()

# Creating an instance of Restaurant with number_served attribute
restaurant_with_customers = Restaurant("Diner Delight", "American")
restaurant_with_customers.display_number_served()

# Changing the number of customers served and displaying it
restaurant_with_customers.set_number_served(50)
restaurant_with_customers.display_number_served()

# Incrementing the number of customers served and displaying it
restaurant_with_customers.increment_number_served(20)
restaurant_with_customers.display_number_served()

# Creating an instance of IceCreamStand
ice_cream_stand = IceCreamStand("Sweet Treats", "Dessert", ["Chocolate", "Vanilla", "Strawberry"])
ice_cream_stand.describe_restaurant()
ice_cream_stand.display_flavors()
