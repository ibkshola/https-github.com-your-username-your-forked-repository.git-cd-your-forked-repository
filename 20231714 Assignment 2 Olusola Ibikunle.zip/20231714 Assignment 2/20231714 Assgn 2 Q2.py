
class User:
    def __init__(self, first_name, last_name, age, email):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.login_attempts = 0

    def describe_user(self):
        print(f"User Information:")
        print(f"Name: {self.first_name} {self.last_name}")
        print(f"Age: {self.age}")
        print(f"Email: {self.email}")

    def greet_user(self):
        print(f"Hello, {self.first_name}!")

    def increment_login_attempts(self):
        self.login_attempts += 1

    def reset_login_attempts(self):
        self.login_attempts = 0


class Privileges:
    def __init__(self):
        self.privileges = ["can add post", "can delete post", "can ban user"]

    def show_privileges(self):
        print("Privileges:")
        for privilege in self.privileges:
            print(f"- {privilege}")


class Admin(User):
    def __init__(self, first_name, last_name, age, email):
        super().__init__(first_name, last_name, age, email)
        self.privileges = Privileges()


# Create instances of User and call methods
user1 = User("John", "Doe", 25, "john.doe@example.com")
user2 = User("Jane", "Smith", 30, "jane.smith@example.com")

user1.describe_user()
user1.greet_user()

user2.describe_user()
user2.greet_user()

# Test login attempts and reset
user3 = User("Alice", "Johnson", 22, "alice.johnson@example.com")
user3.increment_login_attempts()
user3.increment_login_attempts()
print(f"Login Attempts: {user3.login_attempts}")

user3.reset_login_attempts()
print(f"Login Attempts after reset: {user3.login_attempts}")

# Create instance of Admin and call show_privileges method
admin = Admin("Admin", "User", 40, "admin@example.com")
admin.describe_user()
admin.privileges.show_privileges()
